# Readme: ess2008.zip

This ZIP archive holds Round 4 (2008) of the European Social Survey (ESS), in Stata format.

From the ESS website:

> The European Social Survey (the ESS) is an academically-driven social survey designed to chart and explain the interaction between Europe's changing institutions and the attitudes, beliefs and behaviour patterns of its diverse populations.  
<http://www.europeansocialsurvey.org/>

The PDF documentation includes:

- a description brochure
- the questionnaire used for ESS4
- the survey design of ESS4
- a list of variables in all ESS rounds
- a guide on weighting ESS4 data

## Installation

Move the dataset and its documentation folder to your "Datasets" folder.

This enables you to load (open) the dataset with the following command:

	use "Datasets/ess2008.dta", clear

The command clears any previously opened data and implies that you have first set your SRQM folder to act as the working directory for Stata. Read from the course documentation to understand this process if you are not familiar with it.

## Modifications

The dataset was created by subsetting the ESS cumulative dataset to Round 4, and then by removing variables with no observations. The code follows:

	drop if essround != 4

	foreach v of varlist * {
		qui count if !mi(`v')
		if r(N)==0 {
			di "Dropping: " "`v'"
			drop `v'
		}
	}
	
	save ess2008.dta, replace

## Note

This file is part of the teaching material for the class "Statistical Reasoning and Quantitative Methods", taught at Sciences Po, Paris. It is distributed at the following address:    
<http://f.briatte.org/teaching/quanti/>  

Please use for replication purposes only and do not redistribute for any other reason, as there is no guarantee that the teaching version of the dataset reflects the actual survey data in highest quality. Please also remember to systematically cite the correct source for all data. 

François Briatte  
2011-09-29