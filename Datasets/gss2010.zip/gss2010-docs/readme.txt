# Readme: gss2010.zip

This ZIP archive holds data from the U.S. General Social Survey (GSS) for year 2010.

From the GSS website:

> The GSS contains a standard 'core' of demographic, behavioral, and attitudinal questions, plus topics of special interest. Many of the core questions have remained unchanged since 1972 to facilitate time-trend studies as well as replication of earlier findings. The GSS takes the pulse of America, and is a unique and valuable resource. It has tracked the opinions of Americans over the last four decades.  
<http://www3.norc.org/GSS+Website/>

The PDF documentation includes:

- a guide to weighting GSS data (GSS Codebook, Appendix 1)
- a Stata codebook for quicker access to variable codings

A wealth of documentation is available online from the NORC and SDA websites, as well as many others. While NORC should be your first reference, try the SDA pages for a convenient online access to the GSS Codebook:  
<http://sda.berkeley.edu/D3/GSS10/Docyr/gs10.htm>

## Installation

Move the dataset and its documentation folder to your "Datasets" folder.

This enables you to load (open) the dataset with the following command:

	use "Datasets/gss2010.dta", clear

The command clears any previously opened data and implies that you have first set your SRQM folder to act as the working directory for Stata. Read from the course documentation to understand this process if you are not familiar with it.

## Modifications

The dataset is a subset from the GSS 1972-2010 cross-sectional cumulative dataset (Release 1.1, Feb. 2011). The code used to subset and trim the data and to export the Stata codebook follows:

	// Subset.
	keep if year==2010
	
	// Remove empty variables.
	foreach v of varlist * {
		qui su `v'
		if r(N)==0 {
		di "Removing " "`v'"
		drop `v'
		}
	}
	save gss2010.dta, replace

	// Export codebook.
	log using gss2010_codebook.log, name(gss2010) replace
	d
	codebook
	log close gss2010

## Note

This file is part of the teaching material for the class "Statistical Reasoning and Quantitative Methods", taught at Sciences Po, Paris. It is distributed at the following address:    
<http://f.briatte.org/teaching/quanti/>  

Please use for replication purposes only and do not redistribute for any other reason, as there is no guarantee that the teaching version of the dataset reflects the actual survey data in highest quality. Please also remember to systematically cite the correct source for all data. 

François Briatte  
2011-10-24