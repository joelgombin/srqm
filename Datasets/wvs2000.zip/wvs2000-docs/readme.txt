# Readme: wvs2000.zip

This ZIP archive holds data from the 1999-2004 wave of the World Values Survey (WVS) in Stata format.

From the WVS website:

> The World Values Survey (WVS) is a worldwide network of social scientists studying changing values and their impact on social and political life. The WVS in collaboration with EVS (European Values Study) carried out representative national surveys in 97 societies containing almost 90 percent of the world's population. These surveys show pervasive changes in what people want out of life and what they believe. In order to monitor these changes, the EVS/WVS has executed five waves of surveys, from 1981 to 2007.  
<http://www.worldvaluessurvey.org/>

The PDF documentation includes:

- a full questionnaire of all WVS waves
- a questionnaire for Egypt (2000)

## Installation

Move the dataset and its documentation folder to your "Datasets" folder.

This enables you to load (open) the dataset with the following command:

	use "Datasets/wvs2000.dta", clear

The command clears any previously opened data and implies that you have first set your SRQM folder to act as the working directory for Stata. Read from the course documentation to understand this process if you are not familiar with it.

## Modifications

The dataset is a subset of the WVS cumulative dataset, with capitalized country names. No other modification was performed, in order to use the dataset as a teaching example for variable recoding. The example focuses on the data from Egypt (2000).

The code for capitalization (kindly provided at StackOverflow by William A. Huber) follows:

	local varname v2
	local sLabelName: value label `varname'
	di "`sLabelName'"

	levelsof `varname', local(xValues)
	foreach x of local xValues {
	    local sLabel: label (`varname') `x', strict
	    local sLabelNew = proper("`sLabel'")
	    if "`sLabelNew'"=="Usa" {
		    local sLabelNew = upper("`sLabel'")    
	    }
	    noi di "`x': `sLabel' ==> `sLabelNew'"
	    label define `sLabelName' `x' "`sLabelNew'", modify
	}

The list of represented countries follows, with the number of respondents:

	. fre v2

	v2 -- country/region
	---------------------------------------------------------------------
	                        |      Freq.    Percent      Valid       Cum.
	------------------------+--------------------------------------------
	Valid   8  Spain        |       1209       1.98       1.98       1.98
	        11 USA          |       1200       1.97       1.97       3.95
	        12 Canada       |       1931       3.16       3.16       7.11
	        13 Japan        |       1362       2.23       2.23       9.34
	        14 Mexico       |       1535       2.51       2.51      11.85
	        15 S Africa     |       3000       4.91       4.91      16.76
	        19 Sweden       |       1015       1.66       1.66      18.43
	        22 Argentina    |       1280       2.10       2.10      20.52
	        24 S Korea      |       1200       1.97       1.97      22.49
	        27 Puerto Rico  |        720       1.18       1.18      23.67
	        29 Nigeria      |       2022       3.31       3.31      26.98
	        30 Chile        |       1200       1.97       1.97      28.94
	        32 India        |       2002       3.28       3.28      32.22
	        38 Pakistan     |       2000       3.28       3.28      35.50
	        39 China        |       1000       1.64       1.64      37.14
	        44 Turkey       |       3401       5.57       5.57      42.71
	        51 Peru         |       1501       2.46       2.46      45.16
	        53 Venezuela    |       1200       1.97       1.97      47.13
	        57 Zimbabwe     |       1002       1.64       1.64      48.77
	        58 Philippines  |       1200       1.97       1.97      50.74
	        59 Israel       |       1199       1.96       1.96      52.70
	        60 Tanzania     |       1171       1.92       1.92      54.62
	        61 Moldova      |       1008       1.65       1.65      56.27
	        67 Saudi Arabia |       1502       2.46       2.46      58.73
	        69 Bangladesh   |       1500       2.46       2.46      61.18
	        70 Indonesia    |       1004       1.64       1.64      62.83
	        71 Vietnam      |       1000       1.64       1.64      64.47
	        72 Albania      |       1000       1.64       1.64      66.10
	        74 Uganda       |       1002       1.64       1.64      67.74
	        77 Singapore    |       1512       2.48       2.48      70.22
	        81 Serbia       |       1200       1.97       1.97      72.19
	        82 Montenegro   |       1060       1.74       1.74      73.92
	        83 Macedonia    |       1055       1.73       1.73      75.65
	        89 Egypt        |       3000       4.91       4.91      80.56
	        90 Morocco      |       2264       3.71       3.71      84.27
	        91 Iran         |       2532       4.15       4.15      88.42
	        92 Jordan       |       1223       2.00       2.00      90.42
	        93 Bosnia       |       1200       1.97       1.97      92.38
	        96 Algeria      |       1282       2.10       2.10      94.48
	        97 Iraq         |       2325       3.81       3.81      98.29
	        99 Kyrgyzstan   |       1043       1.71       1.71     100.00
	        Total           |      61062     100.00     100.00           
	---------------------------------------------------------------------


## Note

This file is part of the teaching material for the class "Statistical Reasoning and Quantitative Methods", taught at Sciences Po, Paris. It is distributed at the following address:    
<http://f.briatte.org/teaching/quanti/>  

Please use for replication purposes only and do not redistribute for any other reason, as there is no guarantee that the teaching version of the dataset reflects the actual survey data in highest quality. Please also remember to systematically cite the correct source for all data. 

François Briatte  
2011-09-29