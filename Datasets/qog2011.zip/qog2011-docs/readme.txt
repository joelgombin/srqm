# Readme: qog2011.zip

This ZIP archive holds the Quality of Government (QOG) dataset in its most recent revision of April 6, 2011, in Stata format.

From the QOG website:

> Our research addresses the questions of how to create and maintain high quality government institutions and how the quality of such institutions influences public policy in a broader sense.  
<http://www.qog.pol.gu.se/>

The PDF documentation includes only the codebook.

## Installation

Move the dataset and its documentation folder to your "Datasets" folder.

This enables you to load (open) the dataset with the following command:

	use "Datasets/qog2011.dta", clear

The command clears any previously opened data and implies that you have first set your SRQM folder to act as the working directory for Stata. Read from the course documentation to understand this process if you are not familiar with it.

## Modifications

No modifications were applied to the data.

## Note

This file is part of the teaching material for the class "Statistical Reasoning and Quantitative Methods", taught at Sciences Po, Paris. It is distributed at the following address:    
<http://f.briatte.org/teaching/quanti/>  

Please use for replication purposes only and do not redistribute for any other reason, as there is no guarantee that the teaching version of the dataset reflects the actual survey data in highest quality. Please also remember to systematically cite the correct source for all data. 

François Briatte  
2011-09-29