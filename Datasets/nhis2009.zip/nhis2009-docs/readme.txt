# Readme: nhis2009.zip

This ZIP archive holds data for years 2000--2009 of the U.S. National Health Interview Survey (NHIS), in Stata format.

From the NHIS website:

> The National Health Interview Survey (NHIS) has monitored the health of the nation since 1957. NHIS data on a broad range of health topics are collected through personal household interviews. For over 50 years, the U.S. Census Bureau has been the data collection agent for the National Health Interview Survey. Survey results have been instrumental in providing data to track health status, health care access, and progress toward achieving national health objectives.  
<http://www.cdc.gov/nchs/nhis.htm>

The PDF documentation includes:

- a description brochure
- a description of NHIS 2009

## Installation

Move the dataset and its documentation folder to your "Datasets" folder.

This enables you to load (open) the dataset with the following command:

	use "Datasets/nhis2009.dta", clear

The command clears any previously opened data and implies that you have first set your SRQM folder to act as the working directory for Stata. Read from the course documentation to understand this process if you are not familiar with it.

## Modifications

The dataset was downloaded from the NHIS website and left untouched. The NHIS website has been updated since and the precise location of the original dataset has disappeared, but hopefully this dataset should still be valid.

If you want to use the data with individual weights, you should probably run something like this:

	svyset psu [pweight=perweight], strata(strata) vce(linearized) singleunit(missing)

## Note

This file is part of the teaching material for the class "Statistical Reasoning and Quantitative Methods", taught at Sciences Po, Paris. It is distributed at the following address:    
<http://f.briatte.org/teaching/quanti/>  

Please use for replication purposes only and do not redistribute for any other reason, as there is no guarantee that the teaching version of the dataset reflects the actual survey data in highest quality. Please also remember to systematically cite the correct source for all data. 

François Briatte  
2011-09-29