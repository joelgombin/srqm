# Readme: ebm2009.zip

This ZIP archive holds data from the Special Eurobarometer, Ref. 311, Wave 71.1 (2009), on "Europeans and the Economic crisis".

From the Eurobarometer website:

> Special Eurobarometer reports are based on in-depth thematical studies carried out for various services of the European Commission or other EU Institutions and integrated in Standard Eurobarometer's polling waves. Reproduction is authorized, except for commercial purposes, provided the source is acknowledged.  
<http://ec.europa.eu/public_opinion/archives/eb_special_en.htm>

The PDF documentation includes:

- the analysis of the survey by the European Commission
- a sample factsheet (descriptive results) for Greece

## Installation

Move the dataset and its documentation folder to your "Datasets" folder.

This enables you to load (open) the dataset with the following command:

	use "Datasets/ebm2009.dta", clear

The command clears any previously opened data and implies that you have first set your SRQM folder to act as the working directory for Stata. Read from the course documentation to understand this process if you are not familiar with it.

## Modifications

No modifications were applied to the data.

## Note

This file is part of the teaching material for the class "Statistical Reasoning and Quantitative Methods", taught at Sciences Po, Paris. It is distributed at the following address:    
<http://f.briatte.org/teaching/quanti/>  

Please use for replication purposes only and do not redistribute for any other reason, as there is no guarantee that the teaching version of the dataset reflects the actual survey data in highest quality. Please also remember to systematically cite the correct source for all data. 

François Briatte  
2011-09-29